<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap"/>
    <link rel="stylesheet" href="../general.css"/>
    <link rel="stylesheet" href="../navigation.css"/>
    <title>FAQZ</title>
  </head>
  <body>
  <?php require_once("../navbar.php"); ?>
    <div class="title-text">
      <h1>This is FAQZ!</h1>
    </div>
  </body>
</html>