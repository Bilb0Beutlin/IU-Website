<?php
#print_r($_SERVER);
$NAV= array(
     'Home'     => '/GN_Website/zip1411/Main'
    ,'AboutUz'  => '/GN_Website/zip1411/AboutUs'
    ,'Evenz'    => '/GN_Website/zip1411/Events'
    ,'Locationz'=> '/GN_Website/zip1411/Location'
    ,'FAQ'      => '/GN_Website/zip1411/FAQs'
);
$nav=array('
<nav>
      <div class="heading">
        <h4>GameNightZ</h4>
      </div>
      <ul class="nav-links">'
);
#class="active-page"
foreach($NAV as $k=>$v){ #k=key;v=value
    $match=str_replace('/','\/',$v);
    $class='';
    if(preg_match("/$match/",$_SERVER['REQUEST_URI'])){ #überprüfung auf welcher seite man sich befindet
       $class='class="active-page"';
    }
    $nav[]='<li><a '.$class.' href="'.$v.'">'.$k.'</a></li>';
}
$nav[]='<li><a href="#" id="login123">LogIn</a></li>';
$nav[]='</ul></nav>';

echo implode("\n",$nav); #/n=zeilenumbruch
