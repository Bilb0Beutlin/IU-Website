<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap"/>
    <link rel="stylesheet" href="../general.css"/>
    <link rel="stylesheet" href="../navigation.css"/>
    <link rel="stylesheet" href="./location.css"/>
    <title>Locationz</title>
  </head>
  <body>
  <?php require_once("../navbar.php"); ?>
    <header>
      <img src="../Images/roomsetupZ.avif" alt="Bild der Location" class="banner">
    </header>
    <main>
      <section class="location-address">
        <div class="address">
          <h2>Adresse</h2>
          <p>123 Musterstraße, 12345 Musterstadt</p>
        </div>
        <div class="location-photo">
          <img src="../Images/location-photo.jpg" alt="Foto der Location">
        </div>
      </section>
      <section class="directions">
        <h2>Anreise</h2>
        <p>Die Location ist gut erreichbar:</p>
        <ul>
          <li>Mit dem Auto: Hier können Sie die Anfahrt mit dem Auto beschreiben.</li>
          <li>Mit öffentlichen Verkehrsmitteln:
            <ul>
              <li>Bus: Informationen zur Busanreise</li>
              <li>Bahn: Informationen zur Bahnreise</li>
            </ul>
          </li>
        </ul>
      </section>
    </main>
  </body>
</html>