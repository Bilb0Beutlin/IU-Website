<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap"/>
    <link rel="stylesheet" href="../general.css"/>
    <link rel="stylesheet" href="../navigation.css"/>
    <link rel="stylesheet" href="./aboutus.css"/>
    <title>About</title>
  </head>
  <body>
  <?php require_once("../navbar.php"); ?>
    <!-- Hier beginnt die Personenkarte-->
    <header>
        <h1>AboutUz</h1>
        <p>Willkommen bei GameNightz!</p>
        <p>Wir sind hier, um eine Veränderung zu bewirken – eine Veränderung im Leben junger introvertierter Nerds, die das Potenzial haben, ihre Leidenschaft für Spiele und ihre Liebe zur digitalen Welt in eine echte Gemeinschaft zu verwandeln. Bei GameNightz glauben wir fest daran, dass Gaming mehr sein kann als nur ein Hobby. Es kann eine Brücke zu echten Beziehungen sein, ein Weg, um Gleichgesinnte zu treffen und lebenslange Freundschaften zu schmieden.</p>
        <p>Unsere Mission ist es, die Gaming-Welt vom Bildschirm ins echte Leben zu bringen. Wir organisieren Game-Nights, die darauf abzielen, Menschen wie dich zusammenzubringen, die sich in der Welt der Bits und Bytes zu Hause fühlen. Unser Ziel ist es, ein Ort zu sein, an dem du deine Leidenschaft teilen, neue Freunde finden und dich in einer unterstützenden Gemeinschaft verwurzeln kannst. Bei uns geht es nicht nur darum, zu gewinnen oder zu verlieren, sondern darum, gemeinsam zu spielen, zu lachen und zu wachsen.</p>
        <p>In einer Zeit, in der die digitale Welt oft die Oberhand gewinnt, möchten wir einen sicheren Hafen bieten, in dem du die echte Welt entdecken und erleben kannst. Wir verstehen, dass es manchmal schwer sein kann, sich mit anderen zu verbinden, aber wir sind hier, um diese Hürden zu überwinden. GameNightz ist mehr als nur ein Unternehmen – es ist eine Bewegung, die darauf abzielt, die Isolation zu durchbrechen und dir die Gelegenheit zu geben, in eine aufregende Welt voller Möglichkeiten einzutauchen.</p>
        <p>Trete unserer Gemeinschaft bei und sei ein Teil dieser aufregenden Reise. Lass uns zusammenkommen, um zu spielen, zu lernen und zu wachsen. Lass uns Freundschaften schließen, die ein Leben lang halten werden. Lass uns die Welt des Gamings neu definieren und sie zu einem Ort machen, an dem du dich zuhause fühlst.</p>
        <p>Wir freuen uns darauf, dich in einer unserer Game-Nights zu begrüßen, und wir können es kaum erwarten, gemeinsam mit dir zu spielen. Willkommen bei GameNightz – wo die Gaming-Community zum Leben erwacht!</p>
        <p>Gemeinsam sind wir stärker.</p>
    </header>
    <div class="container">
      <h2>Unser Team</h2>
      <div class="team">
        <div class="profile-card">
          <img src="../Images/person1.avif" alt="Mitarbeiter 1">
          <div class="profile-name">Max Mustermann</div>
          <div class="profile-title">CEO</div>
        </div>
        <div class="profile-card">
          <img src="../Images/girl1.avif" alt="Mitarbeiter 2">
          <div class="profile-name">Erika Musterfrau</div>
          <div class="profile-title">CTO</div>
        </div>
        <div class="profile-card">
          <img src="../Images/person1.avif" alt="Mitarbeiter 3">
          <div class="profile-name">Lena Beispiel</div>
          <div class="profile-title">Marketing Manager</div>
        </div>
        <div class="profile-card">
          <img src="../Images/girl1.avif" alt="Mitarbeiter 4">
          <div class="profile-name">Fritz Testperson</div>
          <div class="profile-title">Designer</div>
        </div>
      </div>
    </div>
  </body>
</html>