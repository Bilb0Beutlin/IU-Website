$( document ).ready(function() {
  $('#login123').click(function(){
    $('#dialog').dialog({
  resizable: false,
  height: "auto",
  width: 400,
  modal: true,
  buttons: {
    "Abbrechen": function() {
      $( this ).dialog( "close" );
    },
    "Anmelden": function() {
      
      $( this ).dialog( "close" );
      alert('Hello World!');
    }
  }
});
  })
});
