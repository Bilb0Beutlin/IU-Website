<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap"/>
    
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
    
    <link rel="stylesheet" href="../general.css"/>
    <link rel="stylesheet" href="../navigation.css"/>
    <link rel="stylesheet" href="./main.css"/>
    <link rel="stylesheet" href="./slideshow.css"/>
    <script src="./login.js"></script>
    <title>GameNightZ</title>
  </head>
  <body>
    <!-- Hier beginnt die Navigationsbar-->
<?php require_once("../navbar.php"); ?>
    <!-- Hier endet die Navigationsbar-->
    <!-- Hier beginnt die Slideshow-->
    <div class="slideshow-container">
      <div class="slide fade">
        <div class="numbertext">1 / 3</div>
        <img src="../Images/happypeopleZ.jpg" style="width:100%">
        <div class="text" id="text1">Eventz & Community</div>
      </div>
      <div class="slide fade">
        <div class="numbertext">2 / 3</div>
        <img src="../Images/happyamzockenZ.jpg" style="width:100%">
        <div class="text" id="text2">Fun & Connection</div>
      </div>
      <div class="slide fade">
        <div class="numbertext">3 / 3</div>
        <img src="../Images/setupZ.avif" style="width:100%">
        <div class="text" id="text3">Gamez & Friendz</div>
      </div>
      <a class="prev" onclick="changeSlideIndexBy(-1)">&#10094;</a>
      <a class="next" onclick="changeSlideIndexBy(1)">&#10095;</a>
    </div><br>
    <div style="text-align:center">
      <span class="dot" onclick="changeSlideIndexTo(0)"></span>
      <span class="dot" onclick="changeSlideIndexTo(1)"></span>
      <span class="dot" onclick="changeSlideIndexTo(2)"></span>
    </div>
    <!-- Hier endet die Slideshow-->
    <br><br><br>
    <!-- Hier beginnt der Company-Infotext-->
    <div class="company-info">
      <h1>WILLKOMMEN BEI GAMENIGHTZ!</h1>
      <p>Seit unserer Gründung haben wir unser Herzblut in die Organisation von Gaming-Events gesteckt. Ab dem Moment, als GameNightz ins Leben gerufen wurde, ist es unser Ziel, eine Oase für alle Gaming-Enthusiasten zu schaffen. Seit 2012 sind wir die Anlaufstelle für junge introvertierte Nerds, die ihr Hobby lieben und es mit Gleichgesinnten teilen wollen.</p>
      <p>In unseren Räumlichkeiten erwartet dich die geballte Gaming-Energie. Eine Vielzahl an Konsolen lädt ein zum Zocken und Daddeln, während auf mehreren Bildschirmen die neuesten Streams zu verfolgen sind. Doch wir sind mehr als nur ein Ort des Gaming-Vergnügens. Hier geht es nicht nur um Highscores und Turniere, sondern auch darum, eine Gemeinschaft zu bilden, in der echte Beziehungen und Freundschaften entstehen.</p>
      <p>Für diejenigen, die vielleicht nicht so tief im Gaming-Kosmos verwurzelt sind, sind wir nicht nur eine Bar mit Bildschirmen. Es ist ein Ort, an dem jeder sich wohlfühlen kann – sei es mit einem kühlen Getränk in der Hand oder beim Entdecken von Videospielen, die selbst nach einer Minute fesselnd sind. Egal, ob du ein erfahrener Gamer bist oder gerade erst anfängst, wir heißen dich herzlich willkommen.</p>
      <p>GameNightz - wo Gaming lebendig wird und Verbindungen geschmiedet werden. Sei Teil dieser bewegenden Reise, in der die Welt des Gamings vom Bildschirm ins reale Leben tritt.</p>
    </div>
    <!-- Hier endet der Company-Infotext-->
    <br><br><br><br><br><br><br><br><br>
    <!-- Hier beginnen die Wertekarten-->
    <div class="flip-card-container">
      <div class="flip-card">
        <div class="flip-card-inner">
          <div class="flip-card-front">
            <img src="../Images/icongemeinschaft.png" alt="Icon 1" style="width:200px;height:200px;">
            <br>
            <h3>Gemeinschaft und Verbindung</h3>
          </div>
          <div class="flip-card-back">
            <p>Unser oberstes Ziel ist es, eine inklusive Gemeinschaft zu schaffen, in der junge Menschen, insbesondere introvertierte Nerds, sich willkommen und verstanden fühlen. Wir möchten Menschen zusammenbringen, um echte Verbindungen und Freundschaften zu schaffen.</p>
          </div>
        </div>
      </div>
      <div class="flip-card">
        <div class="flip-card-inner">
          <div class="flip-card-front">
            <img src="../Images/iconparty.png" alt="Icon 2" style="width:200px;height:200px;">
            <br>
            <h3>Spaß und Unterhaltung</h3>
          </div>
          <div class="flip-card-back">
            <p>Wir glauben, dass Spiele in erster Linie Spaß machen sollten. Unser Unternehmen strebt danach, unterhaltsame und spannende Erlebnisse zu bieten, die Menschen jeden Alters begeistern. Unser Ziel ist es, unvergessliche Momente der Freude und des Lachens zu schaffen.</p>
          </div>
        </div>
      </div>
      <div class="flip-card">
        <div class="flip-card-inner">
          <div class="flip-card-front">
            <img src="../Images/iconpflanze.png" alt="Icon 3" style="width:200px;height:200px;">
            <br>
            <h3>Gemeinsames Wachstum</h3>
          </div>
          <div class="flip-card-back">
            <p>Wir möchten unsere Teilnehmer nicht nur unterhalten, sondern auch inspirieren und fördern. Wir setzen uns das Ziel, eine Umgebung zu schaffen, in der Menschen durch das Spielen und soziale Interaktionen persönlich wachsen können. Das gemeinsame Lernen und die Entwicklung von Fähigkeiten stehen im Mittelpunkt unserer Aktivitäten.</p>
          </div>
        </div>
      </div>
      <div class="flip-card">
        <div class="flip-card-inner">
          <div class="flip-card-front">
            <img src="../Images/iconcom.png" alt="Icon 4" style="width:200px;height:200px;">
            <br>
            <h3>Offenheit und Vielfalt</h3>
          </div>
          <div class="flip-card-back">
            <p>Wir schätzen die Unterschiede und die Vielfalt unserer Community. Unser Unternehmen legt großen Wert auf Offenheit und Respekt gegenüber unterschiedlichen Hintergründen, Geschmäckern und Perspektiven. Unser Ziel ist es, eine Umgebung zu schaffen, in der jeder willkommen ist, unabhängig von Geschlecht, Herkunft, Alter oder Spielvorlieben.</p>
          </div>
        </div>
      </div>
    </div>
    <!-- Hier enden die Wertekarten-->
    <br><br><br><br><br><br><br><br><br><br><br><br>

    <script src="./slideshow.js"></script>
<div id="dialog" style="display: none;" title="Basic dialog">
  <p>Geben Sie ihre Anmeldedaten an!!!!!!!</p>
  <input type="text" id="loginName" placeholder="Benutzername"/>
  <input type="password" id="loginPasswort" placeholder="Passwort"/>
</div>
   
</body>
  
</html>