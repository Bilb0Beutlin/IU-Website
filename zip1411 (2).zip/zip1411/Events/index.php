<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap"/>
    <link rel="stylesheet" href="../general.css"/>
    <link rel="stylesheet" href="../navigation.css"/>
    <link rel="stylesheet" href="./events.css"/>
    <title>Evenz</title>
  </head>
  <body>
  <?php require_once("../navbar.php"); ?>
    <div class="calendar-container"> <!-- Alles was mit den Event-karten zu tun hat --> <!-- ----- HIER NICHTS ÄNDERN!!! ----- -->
      <!-- Ein Jahr -->
      <div class="year-container" data-year="year2023">
        <!-- Ein Monat -->
        <div class="month-container" data-month="month0">
          <!-- Überschrift (Monat) -->
          <div class="month-title">
            Januar 2023
          </div>
          <div class="month-content">
            <!-- Ein Event -->
            <div class="event-entry" data-title="Titel" data-date="[1, 1, 2023]" data-time="[0, 0]" onclick="openEventDetails(this)">
              <img src="../Images/Image1.jpg">
              <div class="event-content">
                1. Januar 2023<br>
                Titel
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="event-details-container">
      <div class="event-title">
        Titel
      </div>
      <div class="event-date">
        Datum
      </div>
      <div class="event-time">
        Uhrzeit
      </div>
      <div class="cancel-button" onclick="closeEventDetails()">
        X
      </div>
    </div>
    <script src="./events.js"></script>
  </body>
</html>